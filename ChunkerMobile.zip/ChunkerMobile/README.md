# Chunker Mobile

Android-приложение (Kotlin + Jetpack Compose) для конвертации миров Minecraft Java <-> Bedrock.

## Что уже работает
- выбор папки мира и папки результата (Storage Access Framework)
- копирование мира в кэш, проверка level.dat
- выбор целевой версии (Java / Bedrock), прогресс, сохранение результата

## Что нужно доделать: подключение ядра
Вся конвертация идёт через интерфейс `WorldConverter` (WorldConverter.kt).
Сейчас стоит `PlaceholderConverter`, который выбрасывает ошибку.

1. Найдите ядро Chunker (репозиторий HiveGamesOSS/Chunker) и его Maven-артефакт/сборку.
2. Добавьте его в `app/build.gradle.kts` (dependencies).
3. Напишите класс `ChunkerConverter : WorldConverter`, который вызывает API ядра
   (чтение мира из `input`, запись в `output` в нужной версии).
4. В MainActivity замените `PlaceholderConverter()` на `ChunkerConverter()`.

Если ядро использует классы, которых нет в Android (java.awt, java.nio.file в старых API и т.п.),
их нужно заменить или исключить.

## Сборка без Android Studio (GitHub Actions)
1. Создайте репозиторий на github.com (можно с телефона).
2. Загрузите в него содержимое проекта (распакованный ZIP, папка .github должна попасть в репозиторий).
3. Откройте вкладку Actions: сборка запустится сама (или нажмите Run workflow).
4. Через 3-6 минут откройте завершённый запуск, внизу в Artifacts скачайте ChunkerMobile-apk.
5. Распакуйте ZIP, установите app-debug.apk (разрешите установку из неизвестных источников).

Сборка по-прежнему возможна и в Android Studio: Build > Build APK(s).

## Известные ограничения
- Большие миры упираются в память телефона (включён largeHeap).
- Если Android убьёт приложение в фоне, конвертация прервётся: следующий шаг: Foreground Service.
- На Android 11+ папка Android/data недоступна через выбор папки, мир лучше скопировать в обычную папку.
