package app.chunker.mobile

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Screen(PlaceholderConverter()) } }
    }
}

private fun persist(ctx: Context, uri: Uri) {
    ctx.contentResolver.takePersistableUriPermission(
        uri,
        Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
    )
}

@Composable
fun Screen(converter: WorldConverter) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var src by remember { mutableStateOf<Uri?>(null) }
    var dst by remember { mutableStateOf<Uri?>(null) }
    var target by remember { mutableStateOf(TargetEdition.BEDROCK) }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(0f) }
    var log by remember { mutableStateOf("Выберите мир и папку для результата") }

    val pickSrc = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) {
        if (it != null) { persist(ctx, it); src = it }
    }
    val pickDst = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) {
        if (it != null) { persist(ctx, it); dst = it }
    }

    Column(
        Modifier.fillMaxSize().padding(20.dp).statusBarsPadding(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Chunker Mobile", style = MaterialTheme.typography.headlineMedium)

        OutlinedButton(onClick = { pickSrc.launch(null) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
            Text(if (src == null) "1. Выбрать папку мира" else "Мир выбран ✓")
        }
        OutlinedButton(onClick = { pickDst.launch(null) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
            Text(if (dst == null) "2. Папка для результата" else "Папка результата выбрана ✓")
        }

        Text("3. Конвертировать в:")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TargetEdition.values().forEach { e ->
                FilterChip(
                    selected = target == e,
                    onClick = { if (!busy) target = e },
                    label = { Text(e.label) }
                )
            }
        }

        Button(
            enabled = src != null && dst != null && !busy,
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                scope.launch {
                    busy = true
                    progress = 0f
                    try {
                        val work = File(ctx.cacheDir, "work").apply { deleteRecursively(); mkdirs() }
                        val inDir = File(work, "in")
                        val outDir = File(work, "out").apply { mkdirs() }

                        log = "Копирование мира…"
                        withContext(Dispatchers.IO) { copyTreeToDir(ctx, src!!, inDir) }
                        if (!File(inDir, "level.dat").exists()) error("В папке нет level.dat")

                        withContext(Dispatchers.IO) {
                            converter.convert(inDir, outDir, target) { p, m -> progress = p; log = m }
                        }

                        log = "Сохранение результата…"
                        withContext(Dispatchers.IO) {
                            val root = DocumentFile.fromTreeUri(ctx, dst!!) ?: error("Нет доступа к папке")
                            val dir = root.createDirectory("converted_world") ?: error("Не удалось создать папку")
                            copyDirToTree(ctx, outDir, dir)
                        }
                        log = "Готово ✓"
                    } catch (e: Throwable) {
                        log = "Ошибка: ${e.message}"
                    } finally {
                        File(ctx.cacheDir, "work").deleteRecursively()
                        busy = false
                    }
                }
            }
        ) { Text("Конвертировать") }

        if (busy) LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
        Text(log)
    }
}
