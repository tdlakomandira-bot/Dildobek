package app.chunker.mobile

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import java.io.File

/** Копирует выбранную через SAF папку в обычную папку кэша. */
fun copyTreeToDir(ctx: Context, treeUri: Uri, dest: File) {
    val root = DocumentFile.fromTreeUri(ctx, treeUri) ?: error("Нет доступа к папке")
    copyDoc(ctx, root, dest)
}

private fun copyDoc(ctx: Context, doc: DocumentFile, dest: File) {
    dest.mkdirs()
    for (child in doc.listFiles()) {
        val name = child.name ?: continue
        if (child.isDirectory) {
            copyDoc(ctx, child, File(dest, name))
        } else {
            ctx.contentResolver.openInputStream(child.uri)?.use { input ->
                File(dest, name).outputStream().use { out -> input.copyTo(out) }
            }
        }
    }
}

/** Копирует результат из кэша в выбранную пользователем папку. */
fun copyDirToTree(ctx: Context, src: File, parent: DocumentFile) {
    for (f in src.listFiles().orEmpty()) {
        if (f.isDirectory) {
            val dir = parent.findFile(f.name) ?: parent.createDirectory(f.name)
                ?: error("Не удалось создать папку ${f.name}")
            copyDirToTree(ctx, f, dir)
        } else {
            val target = parent.createFile("application/octet-stream", f.name)
                ?: error("Не удалось создать файл ${f.name}")
            ctx.contentResolver.openOutputStream(target.uri)?.use { out ->
                f.inputStream().use { it.copyTo(out) }
            }
        }
    }
}
