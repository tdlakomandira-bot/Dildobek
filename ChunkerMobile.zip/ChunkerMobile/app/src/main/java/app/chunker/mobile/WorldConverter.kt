package app.chunker.mobile

import java.io.File

enum class TargetEdition(val label: String) {
    JAVA("Java"),
    BEDROCK("Bedrock")
}

/** Единственная точка, где подключается ядро Chunker. Остальной код от него не зависит. */
interface WorldConverter {
    /**
     * @param input  папка мира (внутри level.dat), уже скопирована в кэш приложения
     * @param output пустая папка, куда нужно записать конвертированный мир
     * @param onProgress прогресс 0..1 и текст статуса
     */
    suspend fun convert(
        input: File,
        output: File,
        target: TargetEdition,
        onProgress: (Float, String) -> Unit
    )
}

/** Заглушка: замените на реальную реализацию на базе ядра Chunker. */
class PlaceholderConverter : WorldConverter {
    override suspend fun convert(
        input: File,
        output: File,
        target: TargetEdition,
        onProgress: (Float, String) -> Unit
    ) {
        throw UnsupportedOperationException(
            "Ядро Chunker ещё не подключено. См. README.md"
        )
    }
}
